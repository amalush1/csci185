function color1() {
    console.log('Change background to red')
   document.querySelector('#square1').style.backgroundColor= 'red';
    }


function color2() {
    console.log('Change background to orange')
    document.querySelector('#square2').style.backgroundColor= 'orange';
}

function color3() {
    console.log('Change background to yellow')
    document.querySelector('#square3').style.backgroundColor= 'yellow';
}

function color4() {
    console.log('Change background to green')
    document.querySelector('#square4').style.backgroundColor= 'green';
}

function color5() {
    console.log('Change background to blue')
    document.querySelector('#square5').style.backgroundColor= 'blue';
}

function color6() {
    console.log('Change background to purple')
    document.querySelector('#square6').style.backgroundColor= 'purple';
}

// i just wanted to let you know that i really enjoyed this class despite it being one of my toughest, too. computer science is something i want to get better at because web design facinates me. thanks for being such a caring and patient instructor, sarah!